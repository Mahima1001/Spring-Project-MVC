function loadXmlDoc() {
	errorConsole="";
	document.getElementById("mydiv").innerHTML = "";
	document.getElementById("mydiv2").innerHTML = "";
	document.getElementById("mydiv3").innerHTML = "";
	var form = 'Total Groups:'
		+ '<input type="number" name="totalGroups" id="totalGroups" onChange="getXmlData(0,1,this.value)" required/><br>';
	document.getElementById("mydiv").innerHTML = form;
}

function getXmlData(start, iterationNo, totalGroups) {
	document.getElementById("mydiv2").innerHTML = "";
	if(totalGroups>0){
		totalGroups=Math.ceil(totalGroups);
		if (window.XMLHttpRequest) {
			var xmlhttp = new XMLHttpRequest();
		} else {
			// code for older browsers
			var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				myFunction(this, start, iterationNo, totalGroups);
			}

		};
		xmlhttp.open("GET",
				"http://localhost:8080/spring/resources/result.xml", true);
		xmlhttp.send();
	}
	else{
		document.getElementById("mydiv2").innerHTML="ERROR!! Check Console";
		errorConsole+="Total Groups cannot be negative";

	}
}
function myFunction(xml, start, iterationNo, totalGroups) {
	document.getElementById("mydiv2").innerHTML = "";
	var x, i, xmlDoc, table;
	xmlDoc = xml.responseXML;
	table = "<table><tr><th>Name</th><th>Age</th><th>Occupation</th></tr>";
	x = xmlDoc.getElementsByTagName("details");
	if(x.length>0){
		for (i = 0 + start; i < iterationNo * totalGroups; i++) {
			if (i < x.length) {
				table += "<tr><td>";
				var name = x[i].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
				if(name == null){
					fieldEntry=i+1;
					errorConsole+="Name field"+fieldEntry+"is null";
				}
				else if (name.localeCompare(" ") == 0) {
					table += "N.A.";

				} else {
					table += name;
				}
				table += "</td><td>";

				var age = x[i].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
				if(age==null){
					fieldEntry=i+1;
					errorConsole+="Age field"+fieldEntry+"is null<br>";
				}
				else if (age.localeCompare(" ") == 0) {

					table += "N.A.";
				} else {
					table += age;
				}

				table += "</td><td>";

				var occupation = x[i].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
				if(occupation==null){
					fieldEntry=i+1;
					errorConsole+="Occupation field"+fieldEntry+"is null<br>";
				}
				else if (occupation.localeCompare(" ") == 0)
					table += "N.A.";
				else
					table += occupation;
				table += "</td></tr>";
			}
		}

		table += "</table>";
		var nextstart = i;
		var nextiteration = iterationNo + 1;

		table += "<br>";
		if (i > totalGroups) {
			var prestart = start - totalGroups;
			var preiteration = iterationNo - 1;
			table += "<input type='button' value='back' onClick='getXmlData("
				+ prestart + "," + preiteration + "," + totalGroups
				+ ")'/>";
		}

		if (i < x.length) {
			table += "<input type='button' value='next' onClick='getXmlData("
				+ nextstart + "," + nextiteration + "," + totalGroups
				+ ")'/>";
		}
		document.getElementById("mydiv2").innerHTML = table;
	}
	else{
		document.getElementById.innerHTML="ERROR!! Check Console";
		errorConsole+="<b><u>details</u></b>in xml file is empty<br>";
	}
}