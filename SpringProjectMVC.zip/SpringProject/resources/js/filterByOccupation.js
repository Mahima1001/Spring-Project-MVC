var namesFilterByOcc = [];
var ageFilterByOcc = [];
var occFilterByOcc = [];
var valOcc = "";
function filterByOccupation() {
	errorConsole="";
	document.getElementById("mydiv2").innerHTML = "";
	document.getElementById("mydiv3").innerHTML = "";
	document.getElementById("mydiv2").innerHTML = "<input type='text' name='txtOccupation' onChange='showSpecificOccupation(this.value,1)'/>"
		+ "<input type='button' value='SortByOccupation' onClick='showSpecificOccupation(0,0)'/>";
}

function showSpecificOccupation(value, specific) {
	document.getElementById("mydiv3").innerHTML = "";
	namesFilterByOcc = [];
	ageFilterByOcc = [];
	occFilterByOcc = [];
	if (specific == 1)
		valOcc = value;
	if (window.XMLHttpRequest) {
		var xmlhttp = new XMLHttpRequest();
	} else {
		// code for older browsers
		var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (specific == 1)
				findSpecificOccupation(this);
			if (specific == 0)
				filterAllByOccupation(this);
		}
	};
	xmlhttp.open("GET",
			"http://localhost:8080/spring/resources/result.xml", true);
	xmlhttp.send();
}

function findSpecificOccupation(xml) {
	var x, i, xmlDoc;
	xmlDoc = xml.responseXML;
	x = xmlDoc.getElementsByTagName("details");
	if(x.length>0){
		var flag = 0;
		var j = 0;
		for (i = 0; i < x.length; i++) {

			var occ = x[i].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
			if (occ.localeCompare(valOcc) == 0) {
				flag = 1;
				namesFilterByOcc[j] = x[i].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
				ageFilterByOcc[j] = x[i].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
				occFilterByOcc[j] = occ;
				j++;
			}
		}
		if (flag == 1) {
			displaySpecificOccupation(0, 1);
		} else {
			alert("No result found");
		}
	}
	else{
		document.getElementById.innerHTML="ERROR!! Check Console";
		errorConsole+="<b><u>details</u></b>in xml file is empty<br>";
	}
}

function filterAllByOccupation(xml) {
	var x, i, xmlDoc;
	xmlDoc = xml.responseXML;
	x = xmlDoc.getElementsByTagName("details");
	if (x.length > 0) {
		for (i = 0; i < x.length; i++) {
			namesFilterByOcc[i] = x[i].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
			ageFilterByOcc[i] = x[i].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
			occFilterByOcc[i] = x[i].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
		}
		for (i = 0; i < x.length; i++) {
			for (j = i + 1; j < x.length; j++) {
				if (occFilterByOcc[i] > occFilterByOcc[j]) {
					occFilterByOcc[j] = [ occFilterByOcc[i],
					                      occFilterByOcc[i] = occFilterByOcc[j] ][0];
					namesFilterByOcc[j] = [ namesFilterByOcc[i],
					                        namesFilterByOcc[i] = namesFilterByOcc[j] ][0];
					ageFilterByOcc[j] = [ ageFilterByOcc[i],
					                      ageFilterByOcc[i] = ageFilterByOcc[j] ][0];
				}
			}
		}
		displaySpecificOccupation(0, 1);
	} else {
		document.getElementById.innerHTML="ERROR!! Check Console";
		errorConsole+="<b><u>details</u></b>in xml file is empty<br>";
	}
}

function displaySpecificOccupation(start, iteration) {
	table = "<table><tr><th>Name</th><th>Age</th><th>Occupation</th></tr>";
	if (occFilterByOcc.length - (iteration - 1) * 10 <= 10) {
		flag = 0;
		counter = occFilterByOcc.length - (iteration - 1) * 10;
	} else {
		flag = 1;
		counter = 10;
	}
	for (i = 0 + start; i < counter + start; i++) {
		table += "<tr><td>";
		if(namesFilterByOcc[i]==null)
			errorConsole+="Name field is null";
		else if (namesFilterByOcc[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += namesFilterByOcc[i] + "</td><td>";

		if(ageFilterByOcc[i]==null)
			errorConsole+="Age field is null";
		else if (ageFilterByOcc[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += ageFilterByOcc[i] + "</td><td>";

		if(occFilterByOcc[i]==null)
			errorConsole+="Occupation field is null";
		else if (occFilterByOcc[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += occFilterByOcc[i] + "</td><td>";
		table += "</tr>";
	}
	table += "</table></br>";

	if (iteration != 1) {
		iterationPre = iteration - 1;
		startPre = start - 10;
		table += "<input type='button' value='back' onClick='displaySpecificOccupation("
			+ startPre + "," + iterationPre + ")'/>";
	}
	if (flag == 1) {
		iterationNext = iteration + 1;
		startNext = i;
		table += "<input type='button' value='next' onClick='displaySpecificOccupation("
			+ startNext + "," + iterationNext + ")'/>";
	}

	document.getElementById("mydiv3").innerHTML = table;
}

