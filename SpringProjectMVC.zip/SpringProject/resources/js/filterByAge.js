var names = [];
var y = [];
var occupations = [];
function filterBy() {
	errorConsole="";
	document.getElementById("mydiv").innerHTML = "";
	document.getElementById("mydiv2").innerHTML = "";
	document.getElementById("mydiv3").innerHTML = "";
	document.getElementById("mydiv").innerHTML = "<input type='button' id='filterBYAge' name='filterByAge' value='By Age' onClick='filterByAge()'/>"
		+ "<input type='button' id='filterByOcc' name='filterByOcc' value='By Occupation' onClick='filterByOccupation()'/>";
}

function filterByAge() {
	document.getElementById("mydiv").innerHTML = "";
	document.getElementById("mydiv2").innerHTML = "";
	document.getElementById("mydiv3").innerHTML = "";
	formElementsFilterByAge = "<form>From:<input type='number' name='ageFrom' id='ageFrom' min='0' required/>To:<input type='number' name='ageTo' id='ageTo' min=this.form.ageFrom.value required/><input type='button' name='btnFilterByAge' value='Click' onClick='filterByFromToAge(this.form.ageFrom.value,this.form.ageTo.value,1)'/></form>";
	formElementsFilterByAge += "<form><input type='button' value='SortByAge' onClick='filterByFromToAge(0,0,0)'/></form>";
	document.getElementById("mydiv2").innerHTML = formElementsFilterByAge;

}
function filterByFromToAge(valFrom, valTo, bounds) {
	if(valFrom>=0 && valTo>=0 && valTo-valFrom>=0){
		y = [];
		names == [];
		occupations = [];
		document.getElementById("mydiv3").innerHTML = "";
		if (window.XMLHttpRequest) {
			var xmlhttp = new XMLHttpRequest();
		} else {
			var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				myFunctionFilterByAge(this, valFrom, valTo, bounds);
			}
		};
		xmlhttp.open("GET",
				"http://localhost:8080/spring/resources/result.xml", true);
		xmlhttp.send();
	}
	else{
		document.getElementById("mydiv3").innerHTML="ERROR!! Check Console";
		if(valFrom<0)
			errorConsole+="<u>From</u> field in Filter by Age should be >=0<br>";
		if(valTo<0)
			errorConsole+="<u>To</u> field in Filter by Age should be >=0<br>";
		if(valTo-valFrom<0)
			errorConsole+="<u>To</u> field in Filter by Age should be >= <u>From</u> field<br>";
	}
}

function myFunctionFilterByAge(xml, valFrom, valTo, bounds) {
	xmlDoc = xml.responseXML;
	x = xmlDoc.getElementsByTagName("details");
	if(x.length>0){
		var j = 0;
		for (i = 0; i < x.length; i++) {
			if (bounds == 1) {
				age = x[i].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
				if (age - valFrom >= 0 && age - valTo <= 0) {
					y[j] = age;
					names[j] = x[i].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
					occupations[j] = x[i].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
					j++;
				}
			} else {
				y[i] = x[i].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
				names[i] = x[i].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
				occupations[i] = x[i].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
			}
		}
		for (i = 0; i < y.length; i++) {
			for (j = i + 1; j < y.length; j++) {
				if (y[i] - y[j] >= 0) {
					y[j] = [ y[i], y[i] = y[j] ][0];
					names[j] = [ names[i], names[i] = names[j] ][0];
					occupations[j] = [ occupations[i],
					                   occupations[i] = occupations[j] ][0];
				}
			}
		}
		if (y.length > 0) {
			getFilterByAgeResult(0, 1);
		}
		else {
			alert("No result found");
		}

	}
	else{
		document.getElementById.innerHTML="ERROR!! Check Console";
		errorConsole+="<b><u>details</u></b>in xml file is empty<br>";
	}
}

function getFilterByAgeResult(start, iteration) {
	table = "<table><tr><th>Name</th><th>Age</th><th>Occupation</th></tr>";
	if (y.length - (iteration - 1) * 10 <= 10) {
		flag = 0;
		counter = y.length - (iteration - 1) * 10;
	} else {
		flag = 1;
		counter = 10;
	}
	for (i = 0 + start; i < counter + start; i++) {
		table += "<tr><td>";
		if(names[i] == null)
			errorConsole+="Name field is null<br>";
		else if (names[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += names[i] + "</td><td>";
		if(y[i]==null)
			errorConsole+="Age field is null<br>";
		else if (y[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += y[i] + "</td><td>";
		if(occupations[i]==null)
			errorConsole+="Occupation field is null<br>";
		if (occupations[i].localeCompare(" ") == 0)
			table += "N.A.</td><td>";
		else
			table += occupations[i] + "</td><td>";
		table += "</tr>";
	}
	table += "</table></br>";
	if (iteration != 1) {
		iterationPre = iteration - 1;
		startPre = start - 10;
		table += "<input type='button' value='back' onClick='getFilterByAgeResult("
			+ startPre + "," + iterationPre + ")'/>";
	}
	if (flag == 1) {
		iterationNext = iteration + 1;
		startNext = i;
		table += "<input type='button' value='next' onClick='getFilterByAgeResult("
			+ startNext + "," + iterationNext + ")'/>";
	}

	document.getElementById("mydiv3").innerHTML = table;

}