jobsTable = [];
errorInJobId = [];
errorConsole = "";
errorToConsole = "";

function specifyJobNumber() {
	document.getElementById("mydiv").innerHTML = "";
	document.getElementById("mydiv2").innerHTML = "";
	document.getElementById("mydiv3").innerHTML = "";
	document.getElementById("mydiv").innerHTML = "NO of Jobs: <input type='number' name='NoOfJobs' onChange='loadXmlData(this.value)'/>";
}

function loadXmlData(noOfJobs) {
	errorConsole="";
	document.getElementById("mydiv3").innerHTML = "";
	if (window.XMLHttpRequest) {
		var xmlhttp = new XMLHttpRequest();
	} else {
		// code for older browsers
		var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			createJobs(this, noOfJobs);
		}
	};
	xmlhttp.open("GET",
			"http://localhost:8080/spring/resources/result.xml", true);
	xmlhttp.send();
}
function createJobs(xml, noOfJobs) {
	if (noOfJobs > 0) {
		var x, i, xmlDoc, table;
		xmlDoc = xml.responseXML;
		x = xmlDoc.getElementsByTagName("details");
		if(x.length>0){
			var inEach = x.length / noOfJobs;
			if (inEach < 1) {
				var extraJobsFlag = 1;
				var extraJobs = noOfJobs - x.length;
				noOfJobs = x.length;
				inEach = 1;
			}
			inEach = Math.ceil(inEach);
			table = "<table><tr><th>Job Id</th><th>Job Name</th><th>Data Entries</th><th>Job Status</th><th>Get Job Data</th></tr>";
			var flag2 = 0;
			var counter = 0;
			for (i = 0; i < noOfJobs; i++) {
				dataEntriesInEachJob = 0;
				flag = 0;
				jobId = i + 1;
				jobsTable[i] = "<table><tr><th>Name</th><th>Age</th><th>Occupation</th></tr>";
				table += "<tr><td>" + jobId + "</td><td>Job" + jobId + "</td>";
				for (j = counter; j < (counter + inEach); j++) {
					if (j < x.length) {
						dataNo = j + 1;
						nameForJobData = x[j].getElementsByTagName("Name")[0].childNodes[0].nodeValue;
						jobsTable[i] += "<tr>";
						if (nameForJobData == null) {
							flag = 1;
							errorToConsole += "Name[" + dataNo
							+ "] cannot be null<br>";
							errorInJobId[i] += "Name[" + dataNo
							+ "] cannot be null<br>";
						} else if (nameForJobData.localeCompare(" ") == 0) {
							jobsTable[i] += "<td>N.A.</td>";
						} else
							jobsTable[i] += "<td>" + nameForJobData + "</td>";

						ageForJobData = x[j].getElementsByTagName("Age")[0].childNodes[0].nodeValue;
						if (ageForJobData == null) {
							flag = 1;
							errorToConsole += "Age[" + dataNo
							+ "] cannot be null<br>";
							errorInJobId[i] += "Age[" + dataNo
							+ "] cannot be null<br>";
						} else if (ageForJobData.localeCompare(" ") == 0) {
							jobsTable[i] += "<td>N.A.</td>";
						} else
							jobsTable[i] += "<td>" + ageForJobData + "</td>";

						occForJobData = x[j].getElementsByTagName("Occupation")[0].childNodes[0].nodeValue;
						if (occForJobData == null) {
							flag = 1;
							errorToConsole += "Occupation[" + dataNo
							+ "] cannot be null<br>";
							errorInJobId[i] += "Occupation[" + dataNo
							+ "] cannot be null<br>";
						} else if (occForJobData.localeCompare(" ") == 0) {
							jobsTable[i] += "<td>N.A.</td>";
						} else
							jobsTable[i] += "<td>" + occForJobData + "</td>";

						jobsTable[i] += "</tr>";
						dataEntriesInEachJob++;

					}
				}


				jobsTable[i] += "</table>";
				counter = j;
				if (flag == 1) {
					table+="<td>0</td>";
					table += "<td>Error</td>";
					JobId = i + 1;
					errorConsole += "<b><u>Error in Job" + JobId + "</u></b></br>";
					errorConsole += errorToConsole;
					errorToConsole = "";
					table += "<td><input type='button' value='Error' onClick='displayErrorInJob("
						+ i + ")'/></td></tr>";
				} else {
					table+="<td>"+dataEntriesInEachJob+"</td>";
					table += "<td>Complete</td>";
					table += "<td><input type='button' value='complete' onClick='displayJobData("
						+ i + ")'/></td></tr>";
				}

			}

			if (extraJobsFlag == 1) {
				for (i = 0; i < extraJobs; i++) {
					jobIdForError = x.length + i;
					jobId = x.length + i + 1;
					errorInJobId[jobIdForError] = "Job"
						+ jobId
						+ " doesn't have data since its id is greater than length of xml file data<br>";
					table += "<tr><td>" + jobId + "</td><td>Job" + jobId
					+ "</td>";
					table+="<td>0</td>";
					table += "<td>Error</td>";
					table += "<td><input type='button' value='Error' onClick='displayErrorInJob("
						+ jobIdForError + ")'/></td></tr>";
					errorConsole += "Job"
						+ jobId
						+ " doesn't have data since its id is greater than length of xml file data<br>";
				}
			}
			table += "</table>";
			document.getElementById("mydiv2").innerHTML = table;
		}
		else{
			document.getElementById.innerHTML="ERROR!! Check Console";
			errorConsole+="<b><u>details</u></b>in xml file is empty<br>";
		}
	} else {
		errorConsole += "Number Of Jobs cannot be negative";
		document.getElementById("mydiv3").innerHTML = "ERROR!! Check Console<br>";
	}
}

function displayJobData(jobEntry) {
	document.getElementById("mydiv3").innerHTML = jobsTable[jobEntry];
}

function displayErrorInJob(errorInJob) {
	document.getElementById("mydiv3").innerHTML = errorInJobId[errorInJob];
}
