function displayErrors(){
	document.getElementById("mydiv").innerHTML="";
	document.getElementById("mydiv2").innerHTML="";
	document.getElementById("mydiv3").innerHTML="";
	document.getElementById("mydiv3").innerHTML=errorConsole;
}